import { Octokit } from "@octokit/rest";

export class GitHubManager {
  constructor(authToken) {
    if (!authToken) {
      throw new Error("GitHub Auth Token is required.");
    }
    this.octokit = new Octokit({ auth: authToken });
  }

  async getIssue(owner, repo, issueNumber) {
    const response = await this.octokit.rest.issues.get({
      owner,
      repo,
      issue_number: issueNumber,
    });
    return response.data;
  }

  // ... rest of your methods
}
